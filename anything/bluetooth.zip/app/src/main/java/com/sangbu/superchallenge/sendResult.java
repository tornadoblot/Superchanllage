package com.sangbu.superchallenge;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import app.akexorcist.bluetotohspp.library.BluetoothSPP;

public class sendResult extends AppCompatActivity {

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_result);

    }
}
